/*
 * TODO 使用 wx.readFile 来封装 FileReader
 */
export default class FileReader {
  construct() {
  }
}
