import HTMLMediaElement from './HTMLMediaElement'

export default class HTMLAudioElement extends HTMLMediaElement {
  constructor() {
    super('audio')
  }
}
