import HTMLElement from './HTMLElement'

export default class HTMLMediaElement extends HTMLElement {
  constructor(type) {
    super(type)
  }

  addTextTrack() {
  }

  captureStream() {
  }

  fastSeek() {
  }

  load() {
  }

  pause() {
  }

  play() {
  }
}
