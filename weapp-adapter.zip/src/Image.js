export default function Image() {
  const image = wx.createImage()

  return image
}
