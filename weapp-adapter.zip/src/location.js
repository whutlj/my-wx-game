const location = {
  href: 'game.js',
  reload() {
  }
}

export default location
