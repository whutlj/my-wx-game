import Node from './Node'

export default class ELement extends Node {
  className = ''
  children = []

  constructor() {
    super()
  }
}
