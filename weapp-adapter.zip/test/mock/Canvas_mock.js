export default class Canvas {
  getContext(type) {
    return {}
  }
}
