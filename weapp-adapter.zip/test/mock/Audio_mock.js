export default class Audio {
}
