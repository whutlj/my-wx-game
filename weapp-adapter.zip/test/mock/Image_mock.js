export default class Image {
}
