import { loadEnv } from './vm'
import * as window from '../src/window'

describe('contructor', () => {
  it()
  //it('img instanceof of HTMLImageElement', () => {
    //const img = window.document.createElement('img')
    //expect(img instanceof window.HTMLElement).toEqual(true)
    //expect(img instanceof window.HTMLImageElement).toEqual(true)
  //})

  //it('canvas instance of HTMLCanvasElement', () => {
    //const canvas = window.document.createElement('canvas')
    //expect(canvas instanceof window.HTMLElement).toEqual(true)
    //expect(canvas instanceof window.HTMLCanvasElement).toEqual(true)
  //})

  //it('audio instance of HTMLAudioElement', () => {
    //const audio = window.document.createElement('audio')
    //expect(audio instanceof window.HTMLElement).toEqual(true)
    //expect(audio instanceof window.HTMLAudioElement).toEqual(true)
  //})

  //it('ctx instance of CanvasRenderingContext2D', () => {
    //const canvas = window.document.createElement('canvas')
    //const ctx = canvas.getContext('2d')
    //expect(ctx instanceof window.CanvasRenderingContext2D).toEqual(true)
  //})

  //it('ctx instance of WebGLRenderingContext', () => {
    //const canvas = window.document.createElement('canvas')
    //const ctx = canvas.getContext('webgl')
    //expect(ctx instanceof window.WebGLRenderingContext).toEqual(true)
  //})
})
